package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class DateUtilities {

    public static void selectFutureDate(WebDriver driver, String expectedYear, String expectedMonth, String expectedDay){

        driver.findElement(By.cssSelector("#datepicker")).click(); //TODO: change for PlanBuilder

        new WebDriverWait(driver, 5)
                .until(ExpectedConditions.
                        visibilityOfAllElementsLocatedBy(
                                By.cssSelector(".ui-datepicker-calendar"))); //TODO: change for PlanBuilder

        String monthYearValue = driver.findElement(By.cssSelector(".ui-datepicker-title")).getText();

        while(!(splitIntoParts(monthYearValue).get("month").equals(expectedMonth)
                && splitIntoParts(monthYearValue).get("year").equals(expectedYear)))
        {
            driver.findElement(By.cssSelector(".ui-datepicker-next")).click();
            monthYearValue = driver.findElement(By.cssSelector(".ui-datepicker-title")).getText();
        }

        try {
            driver.findElement(By.partialLinkText(expectedDay)).click();
        }
        catch(NoSuchElementException ex){
            ex.printStackTrace();
            throw ex;
        }
    }

    public static void selectPastDate(WebDriver driver, String expectedYear, String expectedMonth, String expectedDay){

        driver.findElement(By.cssSelector("#datepicker")).click(); //TODO: change for PlanBuilder

        new WebDriverWait(driver, 5)
                .until(ExpectedConditions.
                        visibilityOfAllElementsLocatedBy(
                                By.cssSelector(".ui-datepicker-calendar"))); //TODO: change for PlanBuilder

        String monthYearValue = driver.findElement(By.cssSelector(".ui-datepicker-title")).getText();

        while(!(splitIntoParts(monthYearValue).get("month").equals(expectedMonth)
                && splitIntoParts(monthYearValue).get("year").equals(expectedYear)))
        {
            driver.findElement(By.cssSelector(".ui-datepicker-prev")).click();
            monthYearValue = driver.findElement(By.cssSelector(".ui-datepicker-title")).getText();
        }

        try {
            driver.findElement(By.partialLinkText(expectedDay)).click();
        }
        catch(NoSuchElementException ex){
            ex.printStackTrace();
            throw ex;
        }
    }

    public static void selectToday(WebDriver driver){
        driver.findElement(By.cssSelector("#datepicker")).click(); //TODO: change for PlanBuilder

        new WebDriverWait(driver, 5)
                .until(ExpectedConditions.
                        visibilityOfAllElementsLocatedBy(
                                By.cssSelector(".ui-datepicker-calendar"))); //TODO: change for PlanBuilder

        driver.findElement(By.cssSelector("#datepicker")).sendKeys(Keys.ENTER);
    }

    // TODO: https://www.baeldung.com/java-string-valid-date  Check if passed date is valid i.e. not Feb 30 etc.
    public static Map<String, String> splitIntoParts(String monthYearValue){

        String[] arrayKeys = {"month", "year"};
        String[] arrayValues = monthYearValue.split(" ");

        if(arrayKeys.length != arrayValues.length) {
            throw new IllegalArgumentException("Keys and Values need to have the same length.");
        }

        Map<String,String> monthYearMap = new HashMap<>();
        for (int i = 0; i < arrayKeys.length; i++) {
            monthYearMap.put(arrayKeys[i], arrayValues[i]);
        }

        return monthYearMap;
    }

    /**
     * Refactor for use to compare dates
     */
    private void dateComparator(){
        DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date1 = LocalDate.of(2009, 12, 31);
        LocalDate date2 = LocalDate.of(2010, 01, 31);

        System.out.println("date1 : " + sdf.format(date1));
        System.out.println("date2 : " + sdf.format(date2));

        System.out.println("Is...");
        if (date1.isAfter(date2)) {
            System.out.println("Date1 is after Date2");
        }

        if (date1.isBefore(date2)) {
            System.out.println("Date1 is before Date2");
        }

        if (date1.isEqual(date2)) {
            System.out.println("Date1 is equal Date2");
        }

        System.out.println("CompareTo...");
        if (date1.compareTo(date2) > 0) {
            System.out.println("Date1 is after Date2");
        } else if (date1.compareTo(date2) < 0) {
            System.out.println("Date1 is before Date2");
        } else {
            System.out.println("Date1 is equal to Date2");
        }
    }
}
