package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static utils.DateUtilities.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    protected static WebDriver driver;

    @Before
    public void setup(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    @Test
    public void testCalendar() throws InterruptedException {
        driver.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");

        //selectPastDate(driver,"2020", "January", "23");
        //selectToday(driver);
        selectFutureDate(driver,"2022", "January", "23");

        Thread.sleep(5000);
    }

    @After
    public void tearDown(){
        driver.quit();
    }

}
